import { Component } from '@angular/core';

@Component({
  selector: 'app-editcommunic',
  templateUrl: './editcommunic.component.html',
  styleUrls: ['./editcommunic.component.css']
})
export class EditcommunicComponent {

}
