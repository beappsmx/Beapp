import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newcommunic',
  templateUrl: './newcommunic.component.html',
  styleUrls: ['./newcommunic.component.css']
})
export class NewcommunicComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
